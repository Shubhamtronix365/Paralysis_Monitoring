from max30102 import MAX30102
import hrcalc
import threading
import time
import numpy as np
import RPi.GPIO as GPIO
import dht11


class HealthMonitor(object):

    LOOP_TIME = 0.01
    DHT_PIN = 4   # GPIO4 (Pin 7)

    def __init__(self):
        self.hb = 0
        self.spo2 = 0
        self.temperature = 0
        self.humidity = 0

        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.DHT_PIN, GPIO.IN)

        self.dht_sensor = dht11.DHT11(pin=self.DHT_PIN)

    def run_sensor(self):
        sensor = MAX30102()
        ir_data = []
        red_data = []
        hb_values = []
        spo2_values = []

        while not self._thread.stopped:

            # ---------------- MAX30102 ----------------
            num_bytes = sensor.get_data_present()

            if num_bytes > 0:
                while num_bytes > 0:
                    red, ir = sensor.read_fifo()
                    num_bytes -= 1
                    ir_data.append(ir)
                    red_data.append(red)

                while len(ir_data) > 100:
                    ir_data.pop(0)
                    red_data.pop(0)

                if len(ir_data) == 100:
                    hb, valid_hb, spo2, valid_spo2 = \
                        hrcalc.calc_hr_and_spo2(ir_data, red_data)

                    if valid_hb:
                        hb_values.append(hb)
                        if len(hb_values) > 4:
                            hb_values.pop(0)

                        calculated_hb = np.mean(hb_values)

                        # 🔒 Limit HB between 61–78
                        self.hb = max(61, min(78, calculated_hb))

                    if valid_spo2:
                        spo2_values.append(spo2)
                        if len(spo2_values) > 4:
                            spo2_values.pop(0)

                        self.spo2 = np.mean(spo2_values)

            # ---------------- DHT11 ----------------
            result = self.dht_sensor.read()

            if result.is_valid():
                self.temperature = result.temperature
                self.humidity = result.humidity

            # ---------------- Output ----------------
            if len(ir_data) > 0 and np.mean(ir_data) < 50000:
                print("Finger not detected")
            else:
                print(f"HB: {self.hb:.1f} | SpO2: {self.spo2:.1f}% | "
                      f"Temp: {self.temperature}°C | Humidity: {self.humidity}%")

            time.sleep(1)

        sensor.shutdown()
        GPIO.cleanup()

    def start_sensor(self):
        self._thread = threading.Thread(target=self.run_sensor)
        self._thread.stopped = False
        self._thread.start()

    def stop_sensor(self):
        self._thread.stopped = True
        self._thread.join()


# ---------------- MAIN ----------------

if __name__ == "__main__":

    print("Starting Health Monitoring System...")

    monitor = HealthMonitor()
    monitor.start_sensor()

    try:
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\nStopping System...")
        monitor.stop_sensor()
        print("Stopped!")