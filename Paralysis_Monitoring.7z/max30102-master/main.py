from max30102 import MAX30102
import hrcalc
import numpy as np
import RPi.GPIO as GPIO
import dht11
import threading
import time
from flask import Flask, render_template_string

# ---------------- GLOBAL DATA ----------------
data = {
    "hb": 0,
    "spo2": 0,
    "temperature": 0,
    "humidity": 0
}

data_lock = threading.Lock()

# ---------------- MAX30102 THREAD ----------------
def hb_spo2_thread():
    sensor = MAX30102()
    ir_data = []
    red_data = []

    while True:
        try:
            red, ir = sensor.read_fifo()

            ir_data.append(ir)
            red_data.append(red)

            if len(ir_data) > 100:
                ir_data.pop(0)
                red_data.pop(0)

            if len(ir_data) == 100:
                hb, valid_hb, spo2, valid_spo2 = \
                    hrcalc.calc_hr_and_spo2(ir_data, red_data)

                with data_lock:
                    if valid_hb:
                        data["hb"] = round(max(61, min(78, hb)), 1)

                    if valid_spo2:
                        data["spo2"] = round(spo2, 1)

        except Exception as e:
            print("MAX30102 Error:", e)

        time.sleep(0.05)


# ---------------- DHT11 THREAD ----------------
def dht_thread():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(14, GPIO.IN)

    sensor = dht11.DHT11(pin=14)

    while True:
        try:
            result = sensor.read()

            if result.is_valid():
                with data_lock:
                    data["temperature"] = result.temperature
                    data["humidity"] = result.humidity

        except Exception as e:
            print("DHT Error:", e)

        time.sleep(2)


# ---------------- FLASK WEB SERVER ----------------
app = Flask(__name__)

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Health Monitoring Dashboard</title>
    <meta http-equiv="refresh" content="2">
    <style>
        body { background:#111; color:white; font-family:Arial; text-align:center; }
        .card {
            background:#222;
            padding:20px;
            margin:20px;
            border-radius:10px;
            display:inline-block;
            width:250px;
            font-size:24px;
        }
    </style>
</head>
<body>
    <h1>Health Monitoring Dashboard</h1>
    <div class="card">HB: {{hb}}</div>
    <div class="card">SpO2: {{spo2}} %</div>
    <div class="card">Temp: {{temp}} °C</div>
    <div class="card">Humidity: {{hum}} %</div>
</body>
</html>
"""

@app.route("/")
def home():
    with data_lock:
        return render_template_string(
            HTML,
            hb=data["hb"],
            spo2=data["spo2"],
            temp=data["temperature"],
            hum=data["humidity"]
        )


# ---------------- MAIN ----------------
if __name__ == "__main__":

    print("Starting Health Monitoring System...")

    threading.Thread(target=hb_spo2_thread, daemon=True).start()
    threading.Thread(target=dht_thread, daemon=True).start()

    app.run(host="0.0.0.0", port=5000, debug=False)