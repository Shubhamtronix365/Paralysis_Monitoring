from hb_spo2_monitor import HeartRateMonitor
import time

print("Starting MAX30102 Sensor...")

hrm = HeartRateMonitor(print_raw=False, print_result=True)
hrm.start_sensor()

try:
    while True:
        time.sleep(1)

except KeyboardInterrupt:
    print("\nStopping sensor...")
    hrm.stop_sensor()
    print("Sensor stopped!")