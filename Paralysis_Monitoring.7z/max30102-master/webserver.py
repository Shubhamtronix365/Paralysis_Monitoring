from flask import Flask, render_template_string
import json

app = Flask(__name__)

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Health Monitoring System</title>
    <meta http-equiv="refresh" content="2">
    <style>
        body {
            background-color: #111;
            color: white;
            font-family: Arial;
            text-align: center;
        }
        .card {
            background: #222;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            display: inline-block;
            width: 250px;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <h1>Health Monitoring Dashboard</h1>
    <div class="card">HB: {{hb}}</div>
    <div class="card">SpO2: {{spo2}} %</div>
    <div class="card">Temp: {{temp}} °C</div>
    <div class="card">Humidity: {{hum}} %</div>
</body>
</html>
"""

@app.route("/")
def home():
    with open("data.json") as f:
        data = json.load(f)

    return render_template_string(
        HTML,
        hb=data["hb"],
        spo2=data["spo2"],
        temp=data["temperature"],
        hum=data["humidity"]
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)