import RPi.GPIO as GPIO
import dht11
import time
import json

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(14, GPIO.IN)

sensor = dht11.DHT11(pin=14)

while True:
    result = sensor.read()

    if result.is_valid():
        temperature = result.temperature
        humidity = result.humidity

        with open("data.json", "r+") as f:
            data = json.load(f)
            data["temperature"] = temperature
            data["humidity"] = humidity
            f.seek(0)
            json.dump(data, f)
            f.truncate()

    time.sleep(2)