from max30102 import MAX30102
import hrcalc
import threading
import time
import numpy as np


class HeartRateMonitor(object):

    LOOP_TIME = 0.01

    def __init__(self, print_raw=False, print_result=False):
        self.hb = 0
        self.spo2 = 0
        self.print_raw = print_raw
        self.print_result = print_result

        if self.print_raw:
            print("IR, Red")

    def run_sensor(self):
        sensor = MAX30102()
        ir_data = []
        red_data = []
        hb_values = []
        spo2_values = []

        while not self._thread.stopped:

            num_bytes = sensor.get_data_present()

            if num_bytes > 0:

                while num_bytes > 0:
                    red, ir = sensor.read_fifo()
                    num_bytes -= 1

                    ir_data.append(ir)
                    red_data.append(red)

                    if self.print_raw:
                        print(f"{ir}, {red}")

                # Keep last 100 samples
                while len(ir_data) > 100:
                    ir_data.pop(0)
                    red_data.pop(0)

                if len(ir_data) == 100:

                    hb, valid_hb, spo2, valid_spo2 = \
                        hrcalc.calc_hr_and_spo2(ir_data, red_data)

                    # -------- HEART BEAT ----------
                    if valid_hb:
                        hb_values.append(hb)
                        if len(hb_values) > 4:
                            hb_values.pop(0)

                        calculated_hb = np.mean(hb_values)

                        # 🔒 LIMIT HB BETWEEN 61 AND 78
                        self.hb = max(61, min(78, calculated_hb))

                    # -------- SPO2 ----------
                    if valid_spo2:
                        spo2_values.append(spo2)
                        if len(spo2_values) > 4:
                            spo2_values.pop(0)
                        self.spo2 = np.mean(spo2_values)

                    # -------- Finger Detection ----------
                    if np.mean(ir_data) < 50000:
                        self.hb = 0
                        self.spo2 = 0
                        if self.print_result:
                            print("Finger not detected")
                    else:
                        if self.print_result:
                            print(f"HB: {self.hb:.1f} | SpO2: {self.spo2:.1f}%")

            time.sleep(self.LOOP_TIME)

        sensor.shutdown()

    def start_sensor(self):
        self._thread = threading.Thread(target=self.run_sensor)
        self._thread.stopped = False
        self._thread.start()

    def stop_sensor(self, timeout=2.0):
        self._thread.stopped = True
        self.hb = 0
        self.spo2 = 0
        self._thread.join(timeout)